package com.akira.island.core

import android.Manifest
import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Answer, decline and hang up from the island. Order of attempts:
 * 1. the PendingIntent from the call notification (Samsung Phone, WhatsApp, Telegram, Discord…),
 * 2. TelecomManager for the normal phone call (needs the ANSWER_PHONE_CALLS runtime permission),
 * 3. a short message and the app settings page, so a missing permission is never a silent failure.
 * Every step is logged under the tag "IslandCall".
 */
object CallControl {
    private const val TAG = "IslandCall"

    fun answer(context: Context, c: CallInfo) {
        if (send(context, c.answer, "answer")) return
        if (telecom(context, "answer") { it.acceptRingingCall(); true }) return
        failed(context, c)
    }

    /** Red button of the incoming-call card. */
    fun decline(context: Context, c: CallInfo) {
        if (send(context, c.decline ?: c.hangUp, "decline")) return
        if (endTelephony(context, "decline")) return
        failed(context, c)
    }

    /** Red button while talking. */
    fun hangUp(context: Context, c: CallInfo) {
        if (send(context, c.hangUp ?: c.decline, "hangUp")) return
        if (endTelephony(context, "hangUp")) return
        failed(context, c)
    }

    private fun endTelephony(context: Context, what: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
        return telecom(context, what) { it.endCall() }
    }

    private fun send(context: Context, pi: PendingIntent?, what: String): Boolean {
        if (pi == null) {
            Log.w(TAG, "$what: the notification has no matching action")
            return false
        }
        return try {
            val options = if (Build.VERSION.SDK_INT >= 34) {
                ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                    .toBundle()
            } else null
            pi.send(context, 0, null, null, null, null, options)
            Log.i(TAG, "$what: notification action sent")
            true
        } catch (e: PendingIntent.CanceledException) {
            Log.w(TAG, "$what: notification action is no longer valid", e)
            false
        } catch (e: Exception) {
            Log.w(TAG, "$what: notification action failed", e)
            false
        }
    }

    private fun telecom(context: Context, what: String, block: (TelecomManager) -> Boolean): Boolean {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "$what: ANSWER_PHONE_CALLS is not granted")
            return false
        }
        val tm = context.getSystemService(TelecomManager::class.java) ?: return false
        return try {
            val ok = block(tm)
            Log.i(TAG, "$what: TelecomManager returned $ok")
            ok
        } catch (e: SecurityException) {
            Log.w(TAG, "$what: TelecomManager refused", e)
            false
        } catch (e: Exception) {
            Log.w(TAG, "$what: TelecomManager failed", e)
            false
        }
    }

    private fun failed(context: Context, c: CallInfo) {
        val missing = ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED
        if (missing) {
            Toast.makeText(
                context,
                tr("Разрешите «Телефон» для ответа и сброса из острова", "Allow Phone permission to answer or decline from the island"),
                Toast.LENGTH_LONG,
            ).show()
            runCatching {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        } else {
            // Not a normal phone call (for example a VoIP app without a decline button): open the call screen instead
            runCatching { c.open?.send() }
        }
    }
}
